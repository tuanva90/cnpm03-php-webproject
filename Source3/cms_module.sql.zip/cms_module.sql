-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 17, 2012 at 09:47 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `zendcms_db3`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `cms_module`
-- 

CREATE TABLE `cms_module` (
  `module_id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate latin1_general_ci NOT NULL,
  `file_name` varchar(100) collate latin1_general_ci NOT NULL,
  `is_showed` bit(1) NOT NULL,
  `position` tinyint(2) default NULL,
  `sort_order` tinyint(2) default NULL,
  `option` text collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `cms_module`
-- 

INSERT INTO `cms_module` VALUES (1, 'Login', 'BlkLogin', '', 1, 0, '$use_forgot_password_link=1;$use_keep_signed_in=1;');
INSERT INTO `cms_module` VALUES (2, 'Newest Product', 'BlkNewestProduct', '', 1, 1, '$amount_items=5;');
INSERT INTO `cms_module` VALUES (3, 'Impressive Product', 'BlkImpressiveProduct', '', 2, 1, '$amount_items=10;');
INSERT INTO `cms_module` VALUES (5, 'Header', '', '', 0, 0, '$banner=''header_1.jpg'';$title=''Click and Change'';$welcome_text=''Bring you the easiest way to own websites.'';');
INSERT INTO `cms_module` VALUES (6, 'Module_1', 'BlkModuleDefault', '', 1, 2, '');
INSERT INTO `cms_module` VALUES (7, 'Module_2', 'BlkModuleDefault', '', 1, 3, '');
INSERT INTO `cms_module` VALUES (8, 'Module_3', 'BlkModuleDefault', '', 2, 0, '');
INSERT INTO `cms_module` VALUES (9, 'Main', '', '', 3, 1, '');
INSERT INTO `cms_module` VALUES (10, 'Contact', 'BlkContact', '', 3, 1, '');
INSERT INTO `cms_module` VALUES (11, 'Search', 'BlkSearch', '', 2, 2, '');
